Technical Requirements
Programming Language: Python (version 3.7 or later)

Development tools : jupyter notebook

Libraries Used: Pandas, NumPy, Scikit-learn, Matplotlib, Seaborn

Database: MySQL for data extraction

Version Control: Git & GitHub


