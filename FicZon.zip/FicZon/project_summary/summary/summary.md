Objective

The goal of this project is to automate the lead quality classification (High Potential, Low Potential) to improve sales effectiveness.

Key Findings

Data preprocessing significantly improved model accuracy.

Features like Source, Sales_Agent, and Delivery_Mode were found to be key predictors of lead quality.

The Random Forest model outperformed other models, proving to be the most effective in classifying leads.

Expected Outcomes

Improved efficiency in lead categorization.

Increased sales conversion rates by prioritizing high-potential leads.

Reduced manual effort and human bias in lead classification.
