Data Insights
The dataset consists of 7,422 entries with 9 features related to sales leads.

The primary sources of data include website traffic, referrals, and offline methods.

Some key fields, such as Product_ID, Mobile, and Location, contain missing values and duplicate entries.

The target variable (Status) requires preprocessing before training the machine learning model.

Data Cleaning & Feature Engineering
Missing values were handled using appropriate imputation and removal strategies.

New features were created based on timestamps (Created) and regional data (Location).

Correlation analysis was performed to remove columns that added little value to the model.

Categorical variables were encoded to make them suitable for machine learning algorithms.

Model Evaluation
Various machine learning models were trained, including Logistic Regression, Decision Trees, Random Forest, and XGBoost.

Performance was evaluated using accuracy, precision, recall, and F1-score.

The Random Forest model achieved the highest accuracy, exceeding 85%, making it the best-performing model for this problem.
